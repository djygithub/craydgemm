while true
do
date
/opt/rocm/bin/rocm-smi
sleep 2
done
