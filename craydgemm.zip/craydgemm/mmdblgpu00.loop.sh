export HIP_VISIBLE_DEVICES=0
while true
do
date
./mmdblgpugiops 25000
done

