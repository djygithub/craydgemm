while true
do
date
/opt/rocm/bin/rocm-smi -b
sleep 2
done
