export HIP_VISIBLE_DEVICES=5
while true
do
date
./mmdblgpugiops 25000
done

