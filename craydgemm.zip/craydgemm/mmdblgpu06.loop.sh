export HIP_VISIBLE_DEVICES=6
while true
do
date
./mmdblgpugiops 25000
done

