export HIP_VISIBLE_DEVICES=3
while true
do
date
./mmdblgpugiops 25000
done

