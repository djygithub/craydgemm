./mmdblgpu00.loop.sh &
./mmdblgpu01.loop.sh &
./mmdblgpu02.loop.sh &
./mmdblgpu03.loop.sh &
./mmdblgpu04.loop.sh &
./mmdblgpu05.loop.sh &
./mmdblgpu06.loop.sh &
./mmdblgpu07.loop.sh &


